package com.codeoftheweb.salvo.util;

public enum GameState {

	WAITINGFOROPP,
	WAIT,
	PLAY,
	PLACESHIPS,
	WON,
	LOST,
	TIE,
	UNDEFINED

}
