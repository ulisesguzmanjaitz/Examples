var statics = {
    "D": [
        {
            "cantidad": 0,
            "perc_voted_with_party":0
        }
    ],
    "R": [
        {
            "cantidad": 0,
            "perc_voted_with_party":0
        }
    ],
    "I": [
        {
            "cantidad": 0,
            "perc_voted_with_party":0
        }
    ],
    "Total":[
        {
            "cantidad":0,
            "perc_voted_with_party":0
        }]
};
