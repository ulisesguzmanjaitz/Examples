package com.codeoftheweb.salvo;

import com.codeoftheweb.salvo.models.Game;
import com.codeoftheweb.salvo.models.GamePlayer;
import com.codeoftheweb.salvo.models.Player;
import com.codeoftheweb.salvo.repositories.GamePlayerRepository;
import com.codeoftheweb.salvo.repositories.GameRepository;
import com.codeoftheweb.salvo.repositories.PlayerRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.Date;
import java.time.LocalDateTime;

@SpringBootApplication
public class SalvoApplication {

	public static void main(String[] args) {

		SpringApplication.run(SalvoApplication.class, args);
		System.out.println("HELLO WORD!!");
	}

	@Bean
	public CommandLineRunner initData(PlayerRepository playerRepository, GameRepository gameRepository, GamePlayerRepository gamePlayerRepository) {
		return (args) -> {
			// save a couple of customers
			Player player1  = new Player("davidfc05@gmail.com");
			Player player2  = new Player("rocket@gmail.com");

			playerRepository.save(player1);
			playerRepository.save(player2);


			LocalDateTime a = LocalDateTime.of(2017, 2, 13, 15, 56);
			Game game1= new Game(a);
			gameRepository.save(game1);

			LocalDateTime a2 = LocalDateTime.of(2017, 2, 13, 15, 56);
			Game game2= new Game(a2);
			gameRepository.save(game2);

			GamePlayer gamePlayer1=new GamePlayer(game1,player1);
			gamePlayerRepository.save(gamePlayer1);

			GamePlayer gamePlayer2=new GamePlayer(game2,player2);
			gamePlayerRepository.save(gamePlayer2);




		};
	}

}
