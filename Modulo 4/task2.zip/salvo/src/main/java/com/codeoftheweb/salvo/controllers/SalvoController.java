package com.codeoftheweb.salvo.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;
import java.util.stream.Collectors;

import com.codeoftheweb.salvo.repositories.GameRepository;

@RestController
@RequestMapping ("/api")
public class SalvoController {

    @Autowired
    GameRepository gameRepository;

    @RequestMapping("/games")
    public List<Map<String,Object>>getGamesAll() {
        return gameRepository.findAll().stream().map(game -> game.dto()).collect(Collectors.toList());
    }
}