$(function() {
    loadData()
});

function updateGames(data) {
    let htmlList = data.games.map(function (game) {
        return  '<li>' + new Date(game.creationDate).toLocaleString() + ' ' + game.gamePlayers.map(function(gamePlayer) { return gamePlayer.player.userName}).join(',')  +'</li>';
    }).join('');
  document.getElementById("games-list").innerHTML = htmlList;
}

function updateLeaderboard(data) {
    let playersTable =
        '<thead class="thead-dark">'+
            '<tr>'+
                '<th scope="col">'+
                    'Email'
                +'</th>'+
                '<th scope="col">'+
                    'Total score'
                +'</th>'+
                '<th scope="col">'+
                    'Games won'
                +'</th>'+
                '<th scope="col">'+
                    'Games tied'
                +'</th>'+
                '<th scope="col">'+
                    'Games lost'
                +'</th>'
            +'</tr>'
        +'</thead>'
        +'<tbody>';
    playersTable += data.player.sort(function(a,b){return b.totalScore-a.totalScore}).map(function (player) {
        return '<tr>'+
            '<td>'+
                player.userName
            +'</td>'+
            '<td>'+
                player.totalScore
            +'</td>'+
            '<td>'+
                player.gamesWon
            +'</td>'+
            '<td>'+
                player.gamesTied
            +'</td>'+
            '<td>'+
                player.gamesLost
            +'</td>'
        +'</tr>';
    }).join('');
    playersTable+='</tbody>';
    document.getElementById("leaderboard-table").innerHTML = playersTable;
}

function loadData() {
    $.get("/api/games")
        .done(function(data) {
          updateGames(data);
        })
        .fail(function( jqXHR, textStatus ) {
          alert( "Failed: " + textStatus );
        });
    $.get("/api/leaderboard")
        .done(function(data) {
          updateLeaderboard(data);
        })
        .fail(function( jqXHR, textStatus ) {
          alert( "Failed: " + textStatus );
        });
}
