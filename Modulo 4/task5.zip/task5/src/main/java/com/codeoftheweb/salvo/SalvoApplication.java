package com.codeoftheweb.salvo;

import com.codeoftheweb.salvo.models.*;
import com.codeoftheweb.salvo.repositories.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.ArrayList;
import java.util.Arrays;
import java.time.LocalDateTime;
import java.util.List;

@SpringBootApplication
public class SalvoApplication {

	public static void main(String[] args) {

		SpringApplication.run(SalvoApplication.class, args);
		System.out.println("HELLO WORD!!");
	}

	@Bean
	public CommandLineRunner initData(PlayerRepository playerRepository,
									  GameRepository gameRepository,
									  GamePlayerRepository gamePlayerRepository,
									  ShipRepository shipRepository,
									  SalvoRepository salvoRepository,
									  ScoreRepository scoreRepository) {
		return (args) -> {
			// save a couple of customers
			Player player1  = new Player("davidfc05@gmail.com");
			Player player2  = new Player("rocket@gmail.com");

			playerRepository.save(player1);
			playerRepository.save(player2);

			LocalDateTime a = LocalDateTime.of(2017, 2, 13, 15, 56);
			Game game1= new Game(a);
			gameRepository.save(game1);

			LocalDateTime a2 = LocalDateTime.of(2017, 2, 13, 15, 56);
			Game game2= new Game(a2);
			gameRepository.save(game2);

			GamePlayer gamePlayer1=new GamePlayer(game1,player1);
			gamePlayerRepository.save(gamePlayer1);

			GamePlayer gamePlayer2=new GamePlayer(game1,player2);
			gamePlayerRepository.save(gamePlayer2);

			String battleship = "Battleship";
			String submarine = "Submarine";
			String destroyer = "Destroyer";
			String patrolBoat = "Patrol Boat";


			Ship ship1 = new Ship(destroyer, Arrays.asList("H2", "H3", "H4"),gamePlayer1);
			Ship ship2 = new Ship(submarine, Arrays.asList("E1","F1","G1"), gamePlayer1);
			Ship ship3 = new Ship(patrolBoat, Arrays.asList("B4","B5"), gamePlayer1);
			Ship ship4 = new Ship(destroyer, Arrays.asList("B5","C5","D5"), gamePlayer2);
			Ship ship5 = new Ship(patrolBoat, Arrays.asList("F1","F2"), gamePlayer2);

			shipRepository.save(ship1);
			shipRepository.save(ship2);
			shipRepository.save(ship3);
			shipRepository.save(ship4);
			shipRepository.save(ship5);

			Salvo salvo1 = new Salvo(1,Arrays.asList("H2", "H3", "H4"),gamePlayer1);
			Salvo salvo2 = new Salvo(1,Arrays.asList("E1", "F1", "G1"),gamePlayer2);

			salvoRepository.save(salvo1);
			salvoRepository.save(salvo2);

			Score score1=new Score(game1,player1,1);
			scoreRepository.save(score1);

			Score score2=new Score(game1,player2,0);
			scoreRepository.save(score2);

		};
	}

}
