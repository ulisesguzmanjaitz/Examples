package com.codeoftheweb.salvo.models;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Entity
public class Player {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
    @GenericGenerator(name = "native",  strategy = "native")
    private long id;

    private String userName;

    @OneToMany(mappedBy = "player",fetch = FetchType.EAGER)
    Set<GamePlayer> gamePlayers;

    @OneToMany(mappedBy = "player",fetch = FetchType.EAGER)
    Set<Score> scores;

    public Player(){}

    public Player(String userName){
        this.userName =   userName;
    }

    public Map<String,  Object> makePlayerDTO(){
        Map<String,  Object>    dto=    new LinkedHashMap<>();
        dto.put("id",   this.getId());
        dto.put("userName", this.getUserName());
        return  dto;
    }

    public Map<String,  Object> makePlayerScoreDTO(){
        Map<String, Object> dto = new LinkedHashMap<>();
        dto.put("id", this.getId());
        dto.put("userName", this.getUserName());
        dto.put("totalScore", this.getTotalScore());
        dto.put("gamesWon", this.getGamesWon());
        dto.put("gamesTied", this.getGamesTied());
        dto.put("gamesLost", this.getGamesLost());
        return dto;

    }

    public double getTotalScore() {
        return getGamesWon() * 1.0D + getGamesTied() * 0.5D;
    }

    public long getGamesWon() {
        return getGamesByScore(1.0D).size();
    }

    public long getGamesTied() {
        return getGamesByScore(0.5D).size();
    }

    public long getGamesLost() {
        return getGamesByScore(0.0D).size();
    }

    public Set<Score> getGamesByScore(double score) {
        return this.getScores()
                .stream()
                .filter(sc -> sc.getScore() == score)
                .collect(Collectors.toSet());
    }

    public long getId() {
        return id;
    }

    public String getUserName() {
        return userName;
    }

    public void setEmail(String userName) {
        this.userName = userName;
    }

    public Set<GamePlayer> getGamePlayers() {
        return gamePlayers;
    }

    public void setGamePlayers(Set<GamePlayer> gamePlayers) {
        this.gamePlayers = gamePlayers;
    }

    public Set<Score> getScores() {
        return scores;
    }

    public void setScores(Set<Score> scores) {
        this.scores = scores;
    }

    public float getScore(Game game) {
        return getGamePlayers().stream().filter(gp -> gp.getGame().equals(game)).findFirst().orElse(null).getScore();

    }

}