$(function() {
    loadData()
});
function updateView(data) {
    let htmlList = data.map(function (game) {
        console.log(game.time);
        //created es la key de makeGameDTO para la fecha de creacion
        return  '<i>' + '  &nbsp; ' +  game.gamePlayers.map(function(gamePlayer) { return gamePlayer.player.email}).join(',')  + '  &nbsp; ' +'</i>';
    }).join('vs');
  document.getElementById("games-list").innerHTML = htmlList;
}
function loadData() {
    $.get("/api/games")
        .done(function(data) {
          updateView(data);
        })
        .fail(function( jqXHR, textStatus ) {
          alert( "Failed: " + textStatus );
        });
}