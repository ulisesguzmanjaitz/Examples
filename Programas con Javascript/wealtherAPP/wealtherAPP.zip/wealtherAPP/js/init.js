(function ($) {
  $(function () {

    $('.sidenav').sidenav();

  }); // end of document ready


  $('.carousel.carousel-slider').carousel({
    fullWidth: true
  });

})(jQuery); // end of jQuery name space
